Install All required libraries & packages mentioned in requirement.text file

django admin login credentials
user_id: admin
pass: 12345678
